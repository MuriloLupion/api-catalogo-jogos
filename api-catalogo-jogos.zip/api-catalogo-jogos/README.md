# API de Catálogo de Jogos

Trabalho de API REST em Java com Spring Boot. É um catálogo pessoal para guardar jogos que quero acompanhar. Cada jogo tem nome, gênero, plataforma e a informação de que foi concluído ou não.

## Como executar

Instale **Oracle OpenJDK 25** e **Maven 3.6.3 ou superior**. No IntelliJ, selecione o JDK 25 em **Setup SDK** e atualize o projeto Maven. Abra o terminal na pasta que contém o `pom.xml` e execute:

```bash
mvn spring-boot:run
```

A API ficará em `http://localhost:8080/jogos`. Para parar, pressione `Ctrl+C` no terminal. Também é possível abrir a pasta como projeto Maven no IntelliJ ou Eclipse e executar `CatalogoJogosApplication`.

Os dados ficam em uma `ArrayList` no controller. A lista começa vazia e é perdida quando a aplicação é encerrada. O ID começa em 1 a cada execução, é atribuído pelo servidor e não é reutilizado após uma exclusão.

O projeto usa Spring Boot 4.1.1, compatível com Java 25. A propriedade `java.version` no `pom.xml` continua em 17 para gerar código que também funciona em outras instalações; com o JDK 25 selecionado, a aplicação é compilada e executada normalmente.

## Rotas

| Método | Caminho | O que faz | Resposta normal |
| --- | --- | --- | --- |
| GET | `/jogos` | Lista os jogos, com filtros opcionais | `200 OK` |
| GET | `/jogos/{id}` | Busca um jogo pelo ID | `200 OK` ou `404 Not Found` |
| POST | `/jogos` | Cadastra um jogo | `201 Created` |
| PUT | `/jogos/{id}` | Substitui os dados de um jogo | `200 OK` ou `404 Not Found` |
| DELETE | `/jogos/{id}` | Exclui um jogo | `204 No Content` ou `404 Not Found` |

No POST e no PUT, envie `Content-Type: application/json`. Os campos `nome`, `genero` e `plataforma` são obrigatórios e não podem ser vazios; caso contrário, a API responde `400 Bad Request`. Informe `concluido` como `true` ou `false` (se for omitido, fica `false`). No POST, o ID enviado no JSON é ignorado. No PUT, o ID da URL prevalece e todos os campos devem ser enviados.

Exemplo de JSON para cadastrar:

```json
{
  "nome": "Stardew Valley",
  "genero": "Simulação",
  "plataforma": "PC",
  "concluido": false
}
```

Resposta de exemplo do POST (status `201`):

```json
{
  "id": 1,
  "nome": "Stardew Valley",
  "genero": "Simulação",
  "plataforma": "PC",
  "concluido": false
}
```

## Filtros

Os três parâmetros opcionais da rota `GET /jogos` são `genero`, `plataforma` e `concluido`. É possível usar um, dois ou os três ao mesmo tempo; o jogo deve satisfazer todos os filtros informados. Gênero e plataforma ignoram diferenças entre letras maiúsculas e minúsculas, mas precisam corresponder ao texto completo.

Exemplos (depois de cadastrar jogos compatíveis):

- `GET http://localhost:8080/jogos?genero=Simulação`
- `GET http://localhost:8080/jogos?plataforma=PC`
- `GET http://localhost:8080/jogos?concluido=false`
- `GET http://localhost:8080/jogos?genero=Simulação&plataforma=PC&concluido=false`

Quando não há jogos correspondentes, a resposta é `200 OK` com `[]`.

## Testar no Postman

1. Inicie a API.
2. No Postman, importe `postman/Catalogo de Jogos.postman_collection.json` pela opção **Import**.
3. Execute as requisições na ordem da coleção: cadastrar, listar, buscar pelo ID, aplicar filtros, atualizar, excluir e verificar o `404`.
4. A coleção guarda automaticamente o `id` retornado no cadastro. Se reiniciar a aplicação, comece pelo cadastro novamente.

Também é possível usar **Run collection** para executar a sequência e conferir os testes de status e de conteúdo. Se a porta 8080 estiver ocupada, mude o valor da variável `baseUrl` da coleção para a porta usada pela sua aplicação.

## Como explicar o código

- `CatalogoJogosApplication` inicia o Spring Boot.
- `Jogo` representa o JSON do cadastro: seus atributos são convertidos pelo Spring para JSON nas respostas e do JSON para Java nas requisições.
- `JogoController` contém a lista, as rotas e o contador de IDs. Como o exercício pede apenas `model` e `controller`, não há camada de serviço nem banco de dados.
- `@RequestBody` lê o JSON no POST e PUT. `@PathVariable` lê o ID na URL. `@RequestParam` lê os filtros após `?`.
- `ResponseEntity` define o corpo e o status HTTP. `synchronized` evita que requisições simultâneas gerem o mesmo ID ou modifiquem a lista ao mesmo tempo.

### Exemplo de sequência

1. POST cria `Stardew Valley` e devolve ID `1`.
2. GET `/jogos/1` consulta o jogo.
3. PUT `/jogos/1` altera `concluido` para `true`.
4. GET `/jogos?plataforma=PC&concluido=true` encontra o jogo atualizado.
5. DELETE `/jogos/1` remove o jogo; uma nova consulta pelo ID devolve `404`.

## Estrutura

```text
api-catalogo-jogos/
├── pom.xml
├── README.md
├── postman/
│   └── Catalogo de Jogos.postman_collection.json
└── src/main/java/com/exemplo/catalogojogos/
    ├── CatalogoJogosApplication.java
    ├── model/Jogo.java
    └── controller/JogoController.java
```

## Colocar no GitHub

Crie um repositório vazio no GitHub. Dentro da pasta `api-catalogo-jogos`, execute (troque a URL pela do seu repositório):

```bash
git init
git add .
git commit -m "Criar API de catálogo de jogos"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/api-catalogo-jogos.git
git push -u origin main
```

Não envie a pasta `target/`: ela é gerada pelo Maven e já consta no `.gitignore`.
